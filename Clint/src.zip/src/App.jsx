import { BrowserRouter, Routes, Route } from "react-router-dom";
import { AuthProvider } from "./lib/AuthContext";
import { DefaultRoutes } from "./Components/webRoutes/webroutes";

export default function App() {
  return (
    <AuthProvider>
      <BrowserRouter>
        <Routes>
          {DefaultRoutes.map(({ path, element }) => (
            <Route key={path} path={path} element={element} />
          ))}
        </Routes>
      </BrowserRouter>
    </AuthProvider>
  );
}