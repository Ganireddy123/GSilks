import Home from "../../Pages/Home";
import Login from "../../Pages/Login";
import SignUp from "../../Pages/SignUp";
import ForgotPassword from "../../Pages/ForgotPassword";

const DefaultRoutes = [
  { path: "/", element: <Home /> },
  { path: "/login", element: <Login /> },
  { path: "/signup", element: <SignUp /> },
  { path: "/forgot-password", element: <ForgotPassword /> },
];

export { DefaultRoutes };
